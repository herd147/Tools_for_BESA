import numpy as np

def tal2mni(tal_coords):
    """Einfache Umrechnung von Talairach nach MNI (Lancaster-Transformation)."""
    tal_coords = np.atleast_2d(tal_coords)
    mni = np.zeros_like(tal_coords)
    # Formel für die Transformation
    mni[:, 0] = tal_coords[:, 0] * 0.99
    mni[:, 1] = tal_coords[:, 1] * 0.9688 + tal_coords[:, 2] * 0.042
    mni[:, 2] = -tal_coords[:, 1] * 0.0485 + tal_coords[:, 2] * 0.9189
    return mni

def compute_bsa_statistics(data_dict):
    """Gibt einfach die Daten zurück, die wir schon vorbereitet haben."""
    return data_dict

def mni_to_atlas(coords, atlas_name="glasser", radius_mm=5.0):
    """Dummy-Funktion, da die Atlas-Datenbank fehlt."""
    # Wir geben für jeden Koordinatenpunkt eine leere Struktur zurück
    return [{
        "exact_label": "Atlas nicht verfügbar",
        "neighbours": []
    } for _ in range(len(coords))]

def load_all_subjects(*args, **kwargs):
    """Dummy-Funktion, da wir direkt aus CSV laden."""
    return {}