"""
brain_plot.py
-------------
Visualise BESA dipole locations on the fsaverage brain surface.

Two backends (auto-selected, both pip-installable):
  1. nilearn  – static PNG, lateral + medial views, no Freesurfer needed
  2. MNE-Python Brain  – interactive 3-D viewer (requires MNE >= 1.0)

Coordinates
-----------
BSA files store Talairach coordinates.
This module converts them to MNI152 (via tal2mni) before plotting,
as the fsaverage surface is registered to MNI space.

Usage
-----
    # from project root
    python -m besa_analysis.brain_plot

    # or import and call directly
    from besa_analysis.brain_plot import plot_dipoles_on_brain
    plot_dipoles_on_brain(data, output_dir=Path("."))
"""

from __future__ import annotations

import sys
import warnings
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

_pkg = Path(__file__).resolve().parent.parent
if str(_pkg) not in sys.path:
    sys.path.insert(0, str(_pkg))

from config import (
    BASE_DIR,
    SUBJECTS,
    CONDITIONS,
    OUTPUT_DIR,
    CONDITION_COLORS,
    CONDITION_LABELS,
)

from besa_helpers import tal2mni, compute_bsa_statistics, mni_to_atlas, load_all_subjects


# ---------------------------------------------------------------------------
# Dipole colours and labels
# ---------------------------------------------------------------------------


# Marker size / sphere radius
SPHERE_SIZE_MM = 6  # for nilearn scatter
SPHERE_RADIUS = 8  # for MNE Brain (mm)


# ---------------------------------------------------------------------------
# Collect MNI coordinates from bsa_stats
# ---------------------------------------------------------------------------


def collect_mni_coords(
    bsa_stats: Dict[str, dict],
) -> Dict[str, np.ndarray]:
    """
    Average dipole positions across all conditions, convert to MNI152.

    Returns
    -------
    { 'SD1': (3,), 'SD2': (3,), 'SD3': (3,), 'SD4': (3,) }
    in MNI152 space (mm)
    """
    all_means: List[np.ndarray] = [s["mean"] for s in bsa_stats.values()]
    grand_mean = np.nanmean(all_means, axis=0)  # (n_sources, 3)

    out = {}
    for si in range(grand_mean.shape[0]):
        tal_xyz = grand_mean[si, :3]
        mni_xyz = tal2mni(tal_xyz)[0]
        out[f"SD{si + 1}"] = mni_xyz

    return out


def collect_mni_per_condition(
    bsa_stats: Dict[str, dict],
) -> Dict[str, Dict[str, np.ndarray]]:
    """
    Returns { condition: { 'SD1': mni_xyz, … } }
    """
    result = {}
    for cond, stats in bsa_stats.items():
        result[cond] = {}
        for si in range(stats["mean"].shape[0]):
            tal_xyz = stats["mean"][si, :3]
            result[cond][f"SD{si + 1}"] = tal2mni(tal_xyz)[0]
    return result


# ---------------------------------------------------------------------------
# Atlas comparison table  (Glasser + aparc_sub side by side)
# ---------------------------------------------------------------------------


def print_atlas_comparison(
    coords_grand: Dict[str, np.ndarray],
    radius_mm: float = 5.0,
) -> None:
    """
    Print a side-by-side atlas lookup table for both Glasser (HCPMMP1) and
    aparc_sub (Destrieux 2009) for each dipole's grand-mean MNI coordinate.

    Parameters
    ----------
    coords_grand : { 'SD1': mni_xyz, … }  from collect_mni_coords()
    radius_mm    : neighbourhood search radius passed to mni_to_atlas()
    """
    sd_names = sorted(coords_grand.keys())
    mni_batch = np.array([coords_grand[sd] for sd in sd_names])

    # Run both atlas lookups
    glasser_hits = mni_to_atlas(mni_batch, atlas_name="glasser", radius_mm=radius_mm)
    aparcsub_hits = mni_to_atlas(mni_batch, atlas_name="aparc_sub", radius_mm=radius_mm)

    # ── Header ────────────────────────────────────────────────────────────
    col_w = 32
    sep = "─" * (14 + 24 + col_w * 2 + 6)
    print("\n" + "=" * len(sep))
    print(f"  ATLAS COMPARISON  –  Glasser (HCPMMP1)  vs.  aparc_sub (Destrieux 2009)")
    print(f"  Neighbourhood radius: {radius_mm:.0f} mm")
    print("=" * len(sep))
    print(
        f"  {'Source':<8}  {'MNI (x,y,z)':^20}  "
        f"{'Glasser (exact)':<{col_w}}  {'aparc_sub (exact)':<{col_w}}"
    )
    print("  " + "─" * (8 + 22 + col_w * 2 + 4))

    for sd, g_hit, a_hit in zip(sd_names, glasser_hits, aparcsub_hits):
        xyz = coords_grand[sd]
        coord = f"{xyz[0]:+.1f}, {xyz[1]:+.1f}, {xyz[2]:+.1f}"
        g_lbl = g_hit["exact_label"][: col_w - 1]
        a_lbl = a_hit["exact_label"][: col_w - 1]
        print(
            f"  {CONDITION_LABELS.get(sd, sd):<8}  {coord:^20}  "
            f"{g_lbl:<{col_w}}  {a_lbl:<{col_w}}"
        )

    # ── Top neighbours ─────────────────────────────────────────────────────
    print("\n  Top 3 neighbours per dipole:\n")
    print(
        f"  {'Source':<8}  {'Atlas':<10}  "
        f"{'#1 region (n vox)':<30}  {'#2 region (n vox)':<30}  {'#3 region (n vox)'}"
    )
    print("  " + "─" * 110)

    for sd, g_hit, a_hit in zip(sd_names, glasser_hits, aparcsub_hits):
        lbl = CONDITION_LABELS.get(sd, sd)
        for atlas_lbl, hit in [("Glasser", g_hit), ("aparc_sub", a_hit)]:
            nb_strs = [
                f"{nb['label'][:26]} ({nb['n_voxels']})" for nb in hit["neighbours"][:3]
            ]
            while len(nb_strs) < 3:
                nb_strs.append("–")
            print(
                f"  {lbl:<8}  {atlas_lbl:<10}  "
                f"{nb_strs[0]:<30}  {nb_strs[1]:<30}  {nb_strs[2]}"
            )
        print()  # blank line between dipoles

    print("=" * len(sep) + "\n")


# ---------------------------------------------------------------------------
# Backend 1: nilearn  (static PNG)
# ---------------------------------------------------------------------------


def _plot_nilearn(
    coords_grand: Dict[str, np.ndarray],
    coords_per_cond: Dict[str, Dict[str, np.ndarray]],
    output_dir: Path,
) -> None:
    """
    Render dipole locations on fsaverage using nilearn.

    Each dipole MNI coordinate is projected to the nearest fsaverage5
    vertex.  plot_surf_roi colours the surrounding patch; the result is
    composited into a 2×2 figure (left/right × lateral/medial).

    Produces:
      brain_dipoles_grand.png
      brain_dipoles_<condition>.png
    """
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches
        from nilearn import datasets, plotting, surface
    except ImportError as e:
        print(f"  nilearn not available: {e}")
        print("  Install:  pip install nilearn matplotlib")
        return

    print("  Fetching fsaverage surface …", end=" ", flush=True)
    fsavg = datasets.fetch_surf_fsaverage("fsaverage5")
    print("ok")

    # Load surface meshes once
    mesh_l = surface.load_surf_mesh(fsavg.pial_left)
    mesh_r = surface.load_surf_mesh(fsavg.pial_right)
    verts = {"left": mesh_l[0], "right": mesh_r[0]}

    def _nearest_vertex(mni_xyz: np.ndarray, hemi: str) -> int:
        return int(np.argmin(np.linalg.norm(verts[hemi] - mni_xyz, axis=1)))

    def _make_roi_map(
        coords_dict: Dict[str, np.ndarray],
        hemi: str,
        n_verts: int,
        radius_verts: int = 40,
    ) -> np.ndarray:
        """
        Create a vertex-level map encoding which SD each vertex belongs to.
        Values: 0 = none, 1..4 = SD1..SD4.
        We grow a patch of `radius_verts` nearest vertices around each seed.
        """
        roi_map = np.zeros(n_verts, dtype=float)
        hemi_key = "Left" if hemi == "left" else "Right"

        for sd_name, xyz in coords_dict.items():
            sd_hemi = "Left" if xyz[0] <= 0 else "Right"
            if sd_hemi != hemi_key:
                continue
            sd_num = int(sd_name.replace("SD", ""))
            seed = _nearest_vertex(xyz, hemi)
            # Expand to nearest N vertices for visibility
            dists = np.linalg.norm(verts[hemi] - verts[hemi][seed], axis=1)
            patch = np.argsort(dists)[:radius_verts]
            roi_map[patch] = sd_num

        return roi_map

    # Colour map: SD index (1-4) → RGBA
    import matplotlib.colors as mcolors

    sd_cmap_colors = [
        (0, 0, 0, 0),  # 0 = transparent
        mcolors.to_rgba(CONDITION_COLORS["SD1"]),  # 1 = SD1
        mcolors.to_rgba(CONDITION_COLORS["SD2"]),  # 2 = SD2
        mcolors.to_rgba(CONDITION_COLORS["SD3"]),  # 3 = SD3
        mcolors.to_rgba(CONDITION_COLORS["SD4"]),  # 4 = SD4
    ]
    sd_cmap = mcolors.ListedColormap([c[:3] for c in sd_cmap_colors])
    sd_vmin, sd_vmax = 0, 4

    # Use inflated surface for rendering (sulcal pattern more visible → better 3D look)
    # Vertex projection uses pial (anatomically correct MNI coords)
    PANELS = [
        # (hemi,    view,       sulc,              render_mesh,              row, col)
        ("left", "lateral", fsavg.sulc_left, fsavg.infl_left, 0, 0),
        ("right", "lateral", fsavg.sulc_right, fsavg.infl_right, 0, 1),
        ("left", "medial", fsavg.sulc_left, fsavg.infl_left, 1, 0),
        ("right", "medial", fsavg.sulc_right, fsavg.infl_right, 1, 1),
    ]

    def _one_figure(
        coords_dict: Dict[str, np.ndarray],
        title: str,
        out_path: Path,
    ) -> None:
        # Pre-compute ROI maps for each hemisphere
        n_l = verts["left"].shape[0]
        n_r = verts["right"].shape[0]
        roi_l = _make_roi_map(coords_dict, "left", n_l)
        roi_r = _make_roi_map(coords_dict, "right", n_r)
        roi = {"left": roi_l, "right": roi_r}

        # Render each panel into its own temporary PNG, then tile
        import tempfile, os

        panel_imgs = {}

        for hemi, view, sulc, pial, row, col in PANELS:
            tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
            tmp.close()

            has_data = roi[hemi].max() > 0

            if has_data:
                plotting.plot_surf_roi(
                    surf_mesh=pial,
                    roi_map=roi[hemi],
                    hemi=hemi,
                    view=view,
                    bg_map=sulc,
                    bg_on_data=True,
                    darkness=0.7,  # stronger sulcal shading → more 3D depth
                    cmap=sd_cmap,
                    vmin=sd_vmin,
                    vmax=sd_vmax,
                    colorbar=False,
                    output_file=tmp.name,
                )
            else:
                plotting.plot_surf(
                    surf_mesh=pial,
                    hemi=hemi,
                    view=view,
                    bg_map=sulc,
                    darkness=0.7,
                    colorbar=False,
                    output_file=tmp.name,
                )

            panel_imgs[(row, col)] = tmp.name

        from matplotlib.widgets import Slider
        import matplotlib.colors as mc

        # ── Figure layout: brain grid top, slider strip bottom ────────────
        # Use GridSpec to reserve space at the bottom for 2 sliders
        fig = plt.figure(figsize=(12, 10))
        fig.suptitle(title, fontsize=13, fontweight="bold")

        # Brain panels: rows 0-1 (top 85%), slider rows below
        gs = fig.add_gridspec(
            3,
            2,
            height_ratios=[1, 1, 0.12],
            hspace=0.08,
            wspace=0.04,
            top=0.93,
            bottom=0.12,
            left=0.04,
            right=0.96,
        )
        brain_axes = {
            (0, 0): fig.add_subplot(gs[0, 0]),
            (0, 1): fig.add_subplot(gs[0, 1]),
            (1, 0): fig.add_subplot(gs[1, 0]),
            (1, 1): fig.add_subplot(gs[1, 1]),
        }

        view_labels = {
            (0, 0): "left lateral",
            (0, 1): "right lateral",
            (1, 0): "left medial",
            (1, 1): "right medial",
        }

        # Load panels and build RGBA arrays
        panel_rgba = {}
        for (row, col), img_path in panel_imgs.items():
            img = plt.imread(img_path)
            if img.ndim == 3 and img.shape[2] == 3:
                rgba = np.ones((*img.shape[:2], 4), dtype=np.float32)
                rgba[..., :3] = img
            else:
                rgba = img.astype(np.float32).copy()
            # Store original RGB; alpha/brightness applied dynamically
            panel_rgba[(row, col)] = rgba.copy()
            os.unlink(img_path)

        imshow_objs = {}
        for (row, col), rgba in panel_rgba.items():
            ax = brain_axes[(row, col)]
            imshow_objs[(row, col)] = ax.imshow(rgba, interpolation="bilinear")
            ax.set_axis_off()
            ax.set_title(view_labels[(row, col)], fontsize=10, color="#444444")

        # ── Sliders ───────────────────────────────────────────────────────
        ax_dark = fig.add_axes([0.12, 0.065, 0.35, 0.025])
        ax_opac = fig.add_axes([0.58, 0.065, 0.35, 0.025])

        sl_dark = Slider(
            ax_dark,
            "Darkness",
            0.0,
            1.0,
            valinit=0.70,
            color="#e0a020",
            track_color="#eee",
        )
        sl_opac = Slider(
            ax_opac,
            "Opacity",
            0.1,
            1.0,
            valinit=0.90,
            color="#5588cc",
            track_color="#eee",
        )

        def _apply(val=None):
            darkness = sl_dark.val
            opacity = sl_opac.val
            # brightness: darkness=0 → 1.5, darkness=1 → 0.4
            brightness = 1.5 - darkness * 1.1
            for key, rgba_orig in panel_rgba.items():
                out = rgba_orig.copy()
                # Apply brightness to RGB channels
                out[..., :3] = np.clip(out[..., :3] * brightness, 0, 1)
                # Apply opacity: bg stays transparent, brain gets opacity
                is_bg = np.all(rgba_orig[..., :3] >= 0.93, axis=-1)
                out[is_bg, 3] = 0.0
                out[~is_bg, 3] = opacity
                imshow_objs[key].set_data(out)
            fig.canvas.draw_idle()

        sl_dark.on_changed(_apply)
        sl_opac.on_changed(_apply)
        _apply()  # initial render

        # ── Keyboard shortcuts ────────────────────────────────────────────
        def _on_key(event):
            step = 0.01 if event.key and "shift" in event.key.lower() else 0.05
            k = event.key or ""
            if k in ("d", "D"):
                sl_dark.set_val(
                    np.clip(sl_dark.val + (0.05 if k == "D" else -0.05), 0, 1)
                )
            elif k in ("o", "O"):
                sl_opac.set_val(
                    np.clip(sl_opac.val + (0.05 if k == "O" else -0.05), 0.1, 1)
                )
            elif k == "right":
                sl_dark.set_val(np.clip(sl_dark.val + 0.01, 0, 1))
            elif k == "left":
                sl_dark.set_val(np.clip(sl_dark.val - 0.01, 0, 1))
            elif k == "up":
                sl_opac.set_val(np.clip(sl_opac.val + 0.01, 0.1, 1))
            elif k == "down":
                sl_opac.set_val(np.clip(sl_opac.val - 0.01, 0.1, 1))
            elif k in ("r", "R"):
                sl_dark.set_val(0.70)
                sl_opac.set_val(0.90)

        fig.canvas.mpl_connect("key_press_event", _on_key)

        # ── Legend ────────────────────────────────────────────────────────
        patches = [
            mpatches.Patch(color=CONDITION_COLORS[k], label=CONDITION_LABELS[k]) for k in CONDITION_COLORS
        ]
        fig.legend(
            handles=patches,
            loc="lower center",
            ncol=4,
            fontsize=9,
            framealpha=0.85,
            bbox_to_anchor=(0.5, 0.01),
        )

        fig.savefig(out_path, dpi=150, bbox_inches="tight")
        print(f"  Saved: {out_path}")
        matplotlib.use("MacOSX")  # switch to interactive backend for display
        plt.show()
        plt.close(fig)

    # Grand mean
    _one_figure(
        coords_grand,
        title="Dipole locations – grand mean (MNI152 on fsaverage)",
        out_path=output_dir / "brain_dipoles_grand.png",
    )

    # Per condition
    for cond, cd in coords_per_cond.items():
        lbl = CONDITION_LABELS.get(cond, cond)
        _one_figure(
            cd,
            title=f"Dipole locations – {lbl}",
            out_path=output_dir / f"brain_dipoles_{cond}.png",
        )


# ---------------------------------------------------------------------------
# Slider HTML injected into Plotly output
# ---------------------------------------------------------------------------
_SLIDER_JS = """
<style>
#brain-controls {
  position: fixed;
  bottom: 22px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(255,255,255,0.93);
  border: 1px solid #ccc;
  border-radius: 10px;
  padding: 10px 28px 10px 20px;
  display: flex;
  gap: 36px;
  align-items: center;
  box-shadow: 0 2px 10px rgba(0,0,0,0.15);
  z-index: 9999;
  font-family: Arial, sans-serif;
  font-size: 13px;
}
.bc-group { display:flex; flex-direction:column; align-items:center; gap:3px; }
.bc-group label { font-weight:bold; color:#444; font-size:12px; }
.bc-group input[type=range] { width:180px; cursor:pointer; accent-color:#e0a020; }
.bc-val { font-size:11px; color:#888; }
#key-hint { font-size:11px; color:#aaa; text-align:center; }
</style>
<div id="brain-controls">
  <div class="bc-group">
    <label>&#128262; Darkness</label>
    <input type="range" id="sl-dark" min="0" max="100" value="50">
    <span class="bc-val" id="val-dark">0.50</span>
  </div>
  <div class="bc-group">
    <label>&#127787; Opacity</label>
    <input type="range" id="sl-opac" min="10" max="100" value="55">
    <span class="bc-val" id="val-opac">0.55</span>
  </div>
  <div id="key-hint">&#8592; &#8594; Darkness &nbsp;|&nbsp; &#8593; &#8595; Opacity &nbsp;|&nbsp; R Reset</div>
</div>
<script>
(function() {
  function getPlot() { return document.querySelector('.plotly-graph-div'); }
  function applySliders() {
    var dark = parseInt(document.getElementById('sl-dark').value, 10) / 100;
    var opac = parseInt(document.getElementById('sl-opac').value, 10) / 100;
    document.getElementById('val-dark').textContent = dark.toFixed(2);
    document.getElementById('val-opac').textContent = opac.toFixed(2);
    var plot = getPlot();
    if (!plot || !plot.data) return;
    var lo  = Math.round(40  * (1 - dark));
    var hi  = Math.round(230 * (1 - dark * 0.35));
    var mid = Math.round(lo * 0.4 + hi * 0.6);
    var cs  = [[0,'rgb('+lo+','+lo+','+lo+')'],[0.5,'rgb('+mid+','+mid+','+mid+')'],[1,'rgb('+hi+','+hi+','+hi+')']];
    var brainIdx = [];
    plot.data.forEach(function(t,i){ if(t.name && t.name.indexOf('brain')>=0) brainIdx.push(i); });
    if (!brainIdx.length) return;
    Plotly.restyle(plot, {colorscale: brainIdx.map(function(){return cs;}), opacity: brainIdx.map(function(){return opac;})}, brainIdx);
  }
  function clamp(v,lo,hi){return Math.min(hi,Math.max(lo,v));}
  function nudge(id,d){var s=document.getElementById(id);s.value=clamp(parseInt(s.value,10)+d,parseInt(s.min,10),parseInt(s.max,10));applySliders();}
  document.getElementById('sl-dark').addEventListener('input',applySliders);
  document.getElementById('sl-opac').addEventListener('input',applySliders);
  document.addEventListener('keydown',function(e){
    if(['INPUT','TEXTAREA'].indexOf(e.target.tagName)>=0)return;
    switch(e.code){
      case 'ArrowRight':nudge('sl-dark',+1);e.preventDefault();break;
      case 'ArrowLeft': nudge('sl-dark',-1);e.preventDefault();break;
      case 'ArrowUp':   nudge('sl-opac',+1);e.preventDefault();break;
      case 'ArrowDown': nudge('sl-opac',-1);e.preventDefault();break;
      case 'KeyD':      nudge('sl-dark',e.shiftKey?+5:-5);break;
      case 'KeyO':      nudge('sl-opac',e.shiftKey?+5:-5);break;
      case 'KeyR':      document.getElementById('sl-dark').value=50;document.getElementById('sl-opac').value=55;applySliders();break;
    }
  },true);
  var att=0,tmr=setInterval(function(){var p=getPlot();if((p&&p.data&&p.data.length>0)||att>40){clearInterval(tmr);applySliders();}att++;},150);
})();
</script>
</body>
"""

# ---------------------------------------------------------------------------
# Backend 1b: nilearn → interactive HTML with sliders
# ---------------------------------------------------------------------------


def _plot_nilearn_html(
    coords_grand: Dict[str, np.ndarray],
    coords_per_cond: Dict[str, Dict[str, np.ndarray]],
    output_dir: Path,
) -> None:
    """
    Render brain panels as base64-embedded PNGs inside a single HTML file.
    The HTML contains two range sliders:
      • Darkness   – CSS brightness filter (simulates sulcal shading depth)
      • Opacity    – CSS opacity of the brain surface

    One HTML file is written per dataset (grand mean + per condition).
    Open directly in any browser – no server needed.
    """
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches
        from nilearn import datasets, plotting, surface
        import base64, tempfile, os
    except ImportError as e:
        print(f"  nilearn not available: {e}")
        return

    print("  Fetching fsaverage surface …", end=" ", flush=True)
    fsavg = datasets.fetch_surf_fsaverage("fsaverage5")
    print("ok")

    mesh_l = surface.load_surf_mesh(fsavg.pial_left)
    mesh_r = surface.load_surf_mesh(fsavg.pial_right)
    verts = {"left": mesh_l[0], "right": mesh_r[0]}

    import matplotlib.colors as mcolors

    sd_cmap = mcolors.ListedColormap(
        [(0, 0, 0)] + [mcolors.to_rgb(CONDITION_COLORS[f"SD{i}"]) for i in range(1, 5)]
    )

    def _nearest_vertex(xyz, hemi):
        return int(np.argmin(np.linalg.norm(verts[hemi] - xyz, axis=1)))

    def _make_roi_map(coords_dict, hemi, radius_verts=40):
        n = verts[hemi].shape[0]
        roi = np.zeros(n, dtype=float)
        hkey = "Left" if hemi == "left" else "Right"
        for sd_name, xyz in coords_dict.items():
            if ("Left" if xyz[0] <= 0 else "Right") != hkey:
                continue
            seed = _nearest_vertex(xyz, hemi)
            dists = np.linalg.norm(verts[hemi] - verts[hemi][seed], axis=1)
            roi[np.argsort(dists)[:radius_verts]] = int(sd_name.replace("SD", ""))
        return roi

    PANELS = [
        ("left", "lateral", fsavg.sulc_left, fsavg.infl_left, "left lateral"),
        ("right", "lateral", fsavg.sulc_right, fsavg.infl_right, "right lateral"),
        ("left", "medial", fsavg.sulc_left, fsavg.infl_left, "left medial"),
        ("right", "medial", fsavg.sulc_right, fsavg.infl_right, "right medial"),
    ]
    # grid positions: (panel_index) → (row, col)
    GRID = [(0, 0), (0, 1), (1, 0), (1, 1)]

    def _render_panels_b64(coords_dict):
        """Render each panel to PNG and return list of base64 strings."""
        roi_l = _make_roi_map(coords_dict, "left")
        roi_r = _make_roi_map(coords_dict, "right")
        roi = {"left": roi_l, "right": roi_r}
        b64s = []

        for hemi, view, sulc, pial, _ in PANELS:
            tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
            tmp.close()
            has_data = roi[hemi].max() > 0

            if has_data:
                plotting.plot_surf_roi(
                    surf_mesh=pial,
                    roi_map=roi[hemi],
                    hemi=hemi,
                    view=view,
                    bg_map=sulc,
                    bg_on_data=True,
                    darkness=0.7,
                    cmap=sd_cmap,
                    vmin=0,
                    vmax=4,
                    colorbar=False,
                    output_file=tmp.name,
                )
            else:
                plotting.plot_surf(
                    surf_mesh=pial,
                    hemi=hemi,
                    view=view,
                    bg_map=sulc,
                    darkness=0.7,
                    colorbar=False,
                    output_file=tmp.name,
                )

            with open(tmp.name, "rb") as f:
                b64s.append(base64.b64encode(f.read()).decode())
            os.unlink(tmp.name)

        return b64s

    def _build_html(coords_dict, title, out_path):
        b64s = _render_panels_b64(coords_dict)
        panel_labels = [p[4] for p in PANELS]

        # Legend HTML
        legend_items = "".join(
            f"""<span style="display:inline-flex;align-items:center;margin:0 10px;">
              <span style="width:14px;height:14px;border-radius:50%;
                           background:{CONDITION_COLORS[k]};display:inline-block;
                           margin-right:5px;border:1px solid #555"></span>
              {CONDITION_LABELS[k]}</span>"""
            for k in CONDITION_COLORS
        )

        # IMG tags with data URIs
        img_tags = ""
        for i, (b64, lbl) in enumerate(zip(b64s, panel_labels)):
            row, col = GRID[i]
            img_tags += f"""
            <div style="grid-row:{row + 1};grid-column:{col + 1};text-align:center;">
              <div style="font-size:11px;color:#666;margin-bottom:4px;">{lbl}</div>
              <img class="brain-panel"
                   src="data:image/png;base64,{b64}"
                   style="width:100%;height:auto;transition:filter 0.1s,opacity 0.1s;"
              />
            </div>"""

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{title}</title>
<style>
  body  {{ font-family: Arial, sans-serif; background: #f8f8f8;
           display: flex; flex-direction: column; align-items: center;
           padding: 20px; }}
  h2    {{ color: #333; margin-bottom: 6px; text-align: center; }}
  .controls {{
    background: white; border: 1px solid #ddd; border-radius: 8px;
    padding: 16px 28px; margin: 14px 0; display: flex;
    gap: 40px; align-items: center; box-shadow: 0 2px 6px #0001;
  }}
  .ctrl-group {{ display: flex; flex-direction: column; align-items: center; gap: 4px; }}
  .ctrl-group label {{ font-size: 13px; font-weight: bold; color: #444; }}
  .ctrl-group input[type=range] {{ width: 200px; cursor: pointer; }}
  .val-display {{ font-size: 12px; color: #888; }}
  .brain-grid {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 1fr 1fr;
    gap: 8px;
    width: min(900px, 96vw);
    background: white;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 12px;
    box-shadow: 0 2px 8px #0001;
  }}
  .legend {{
    margin-top: 12px; font-size: 13px; display: flex;
    flex-wrap: wrap; justify-content: center; gap: 4px;
  }}
</style>
</head>
<body>
<h2>{title}</h2>

<div id="focusbanner"
  style="margin:8px auto 4px auto;padding:8px 24px;border-radius:6px;font-size:13px;
         background:#fff3cd;border:2px solid #ffc107;color:#856404;
         cursor:pointer;display:inline-block;font-weight:bold;"
  onclick="activateKeys()">
  ⌨️  Click here first – then use keyboard shortcuts
</div>

<div id="keyhelp"
  style="margin:4px 0 8px 0;font-size:11px;color:#4a7c4e;text-align:center;
         display:none;background:#e8f5e9;padding:5px 12px;border-radius:5px;">
  ✓ Keyboard active &nbsp;|&nbsp;
  ← → Darkness &nbsp;|&nbsp; ↑ ↓ Opacity &nbsp;|&nbsp;
  D/d ±5% Darkness &nbsp;|&nbsp; O/o ±5% Opacity &nbsp;|&nbsp; R Reset
</div>

<div class="controls">
  <div class="ctrl-group">
    <label>🔆 Darkness (sulcal shading)</label>
    <input type="range" id="darknessSlider" min="0" max="100" value="70"
           oninput="updateBrain()">
    <span class="val-display" id="darknessVal">0.70</span>
  </div>
  <div class="ctrl-group">
    <label>🌫 Opacity</label>
    <input type="range" id="opacitySlider" min="10" max="100" value="90"
           oninput="updateBrain()">
    <span class="val-display" id="opacityVal">0.90</span>
  </div>
</div>

<div class="brain-grid">
  {img_tags}
</div>

<div class="legend">{legend_items}</div>



<script>
/* ── render ──────────────────────────────────────────────────── */
function updateBrain() {{
  var darkness   = document.getElementById('darknessSlider').value / 100;
  var opacity    = document.getElementById('opacitySlider').value  / 100;
  document.getElementById('darknessVal').textContent = darkness.toFixed(2);
  document.getElementById('opacityVal').textContent  = opacity.toFixed(2);
  var brightness = 1.5 - darkness * 1.1;
  var contrast   = 0.8 + darkness * 0.8;
  document.querySelectorAll('.brain-panel').forEach(function(img) {{
    img.style.filter  = 'brightness(' + brightness.toFixed(2) + ') contrast(' + contrast.toFixed(2) + ')';
    img.style.opacity = opacity.toFixed(2);
  }});
}}

function clamp(v, lo, hi) {{ return Math.min(hi, Math.max(lo, v)); }}

function nudge(id, delta) {{
  var s = document.getElementById(id);
  s.value = clamp(parseInt(s.value, 10) + delta, parseInt(s.min, 10), parseInt(s.max, 10));
  updateBrain();
}}

/* ── keyboard ────────────────────────────────────────────────── */
var keysActive = false;

function activateKeys() {{
  keysActive = true;
  document.getElementById('focusbanner').style.display = 'none';
  document.getElementById('keyhelp').style.display     = 'block';
}}

/* Use capture=true so we intercept before browser / slider defaults */
document.addEventListener('keydown', function(e) {{
  if (!keysActive) return;

  /* block arrow-key page scroll */
  if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].indexOf(e.key) >= 0)
    e.preventDefault();

  var step = e.shiftKey ? 1 : 5;

  /* e.code is layout-independent (works on QWERTY, QWERTZ, AZERTY …) */
  switch (e.code) {{
    case 'KeyD':
      if (e.shiftKey) nudge('darknessSlider', +5);
      else            nudge('darknessSlider', -5);
      break;
    case 'KeyO':
      if (e.shiftKey) nudge('opacitySlider', +5);
      else            nudge('opacitySlider', -5);
      break;
    case 'ArrowRight': nudge('darknessSlider', +1); break;
    case 'ArrowLeft':  nudge('darknessSlider', -1); break;
    case 'ArrowUp':    nudge('opacitySlider',  +1); break;
    case 'ArrowDown':  nudge('opacitySlider',  -1); break;
    case 'KeyR':
      document.getElementById('darknessSlider').value = 70;
      document.getElementById('opacitySlider').value  = 90;
      updateBrain();
      break;
  }}
}}, true);   /* ← capture phase */

updateBrain();
</script>
</body>
</html>"""

        out_path.write_text(html, encoding="utf-8")
        print(f"  HTML: {out_path.resolve()}")

    # --- Grand mean ---
    grand_html = output_dir / "brain_dipoles_grand.html"
    _build_html(
        coords_grand,
        title="Dipole locations – grand mean (MNI152 on fsaverage)",
        out_path=grand_html,
    )
    import webbrowser

    webbrowser.open(grand_html.resolve().as_uri())

    # --- Per condition ---
    for cond, cd in coords_per_cond.items():
        lbl = CONDITION_LABELS.get(cond, cond)
        _build_html(
            cd,
            title=f"Dipole locations – {lbl}",
            out_path=output_dir / f"brain_dipoles_{cond}.html",
        )


# ---------------------------------------------------------------------------
# Backend 2: MNE Brain (interactive)
# ---------------------------------------------------------------------------


def _plot_mne_brain(
    coords_grand: Dict[str, np.ndarray],
    coords_per_cond: Dict[str, Dict[str, np.ndarray]],
    output_dir: Path,
    interactive: bool = True,
) -> None:
    """
    Render dipole locations with mne.viz.Brain (pysurfer/PyVista backend).

    Requires:  pip install mne pyvista pyvistaqt
    """
    try:
        import mne
    except ImportError:
        print("  MNE-Python not found.  pip install mne")
        return

    print(f"  MNE version: {mne.__version__}")

    def _one_brain(
        coords_dict: Dict[str, np.ndarray],
        title: str,
        out_path: Optional[Path],
    ) -> None:
        brain = mne.viz.Brain(
            "fsaverage",
            hemi="both",
            surf="pial",
            subjects_dir=mne.datasets.sample.data_path() / "subjects",
            background="white",
            size=(900, 700),
            title=title,
        )

        for sd_name, xyz in coords_dict.items():
            color = CONDITION_COLORS.get(sd_name, "gray")
            label = CONDITION_LABELS.get(sd_name, sd_name)
            brain.add_foci(
                xyz,
                coords_as_verts=False,
                hemi="lh" if xyz[0] < 0 else "rh",
                color=color,
                scale_factor=0.6,
                name=label,
            )

        if out_path:
            brain.save_image(str(out_path))
            print(f"  Saved: {out_path}")
        if interactive:
            brain.show_view("lateral")
            input("  Press Enter to close MNE Brain …")
        brain.close()

    _one_brain(
        coords_grand,
        title="Dipole locations – grand mean",
        out_path=output_dir / "brain_dipoles_grand_mne.png",
    )

    for cond, cd in coords_per_cond.items():
        lbl = CONDITION_LABELS.get(cond, cond)
        _one_brain(
            cd,
            title=f"Dipole locations – {lbl}",
            out_path=output_dir / f"brain_dipoles_{cond}_mne.png",
        )


# ---------------------------------------------------------------------------
# Backend 3: Plotly  (interactive HTML + static PNG, true 3-D lighting)
# ---------------------------------------------------------------------------

import plotly.graph_objects as go 

def _sphere_mesh(center, color, label, radius=3.5):
    """Erzeugt eine 3D-Kugel für Plotly."""
    phi = np.linspace(0, np.pi, 15)
    theta = np.linspace(0, 2 * np.pi, 15)
    ph, th = np.meshgrid(phi, theta)
    x = center[0] + radius * np.sin(ph) * np.cos(th)
    y = center[1] + radius * np.sin(ph) * np.sin(th)
    z = center[2] + radius * np.cos(ph)
    
    # Triangulierung für Mesh3d
    return go.Mesh3d(
        x=x.ravel(), y=y.ravel(), z=z.ravel(),
        alphahull=0,
        color=color,
        name=label,
        showlegend=True,
        lighting=dict(ambient=0.6, diffuse=0.8, specular=0.5),
        hovertemplate=f"<b>{label}</b><br>MNI: %{{x:.1f}}, %{{y:.1f}}, %{{z:.1f}}<extra></extra>"
    )
    """Return (x, y, z, i, j, k) for a UV sphere centered at `center`."""
    phi = np.linspace(0, np.pi, n)
    theta = np.linspace(0, 2 * np.pi, 2 * n)
    ph, th = np.meshgrid(phi, theta)
    x = center[0] + radius * np.sin(ph) * np.cos(th)
    y = center[1] + radius * np.sin(ph) * np.sin(th)
    z = center[2] + radius * np.cos(ph)
    x, y, z = x.ravel(), y.ravel(), z.ravel()

    # Triangulate with Delaunay on the unit sphere
    from scipy.spatial import ConvexHull

    pts_unit = np.column_stack(
        [
            np.sin(ph.ravel()) * np.cos(th.ravel()),
            np.sin(ph.ravel()) * np.sin(th.ravel()),
            np.cos(ph.ravel()),
        ]
    )
    hull = ConvexHull(pts_unit)
    i, j, k = hull.simplices.T
    return x, y, z, i, j, k


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def plot_dipoles_on_brain(bsa_stats: Dict[str, dict], output_dir: Path, backend: str = "plotly"):
    """
    Plottet ALLE Bedingungen gleichzeitig in ein 3D-Gehirn.
    """
    from nilearn import datasets, surface
    
    print(f"  -> Initialisiere 3D-Plot für {len(bsa_stats)} Gruppen...")
    fsavg = datasets.fetch_surf_fsaverage("fsaverage5")
    
    # Gehirn-Oberflächen laden
    meshes = {}
    for hemi, pial_key in [("left", "pial_left"), ("right", "pial_right")]:
        verts, faces = surface.load_surf_mesh(getattr(fsavg, pial_key))
        meshes[hemi] = (verts, faces)

    # Brain Traces (transparentes Grau)
    brain_traces = []
    for hemi in ["left", "right"]:
        v, f = meshes[hemi]
        # Wir erstellen ein Intensitäts-Array (alle Werte auf 1), 
        # damit der Slider die Colorscale (Helligkeit) steuern kann.
        intensity = np.ones(len(v)) 
        
        brain_traces.append(go.Mesh3d(
            x=v[:, 0], y=v[:, 1], z=v[:, 2], 
            i=f[:, 0], j=f[:, 1], k=f[:, 2],
            intensity=intensity,
            colorscale=[[0, 'gray'], [1, 'gray']], # Startwert
            showscale=False,
            opacity=0.15, 
            hoverinfo="skip", 
            showlegend=False,
            name="brain"  # Wichtig für die Erkennung im JS
        ))
    dipole_traces = []
    
    # SCHLEIFE ÜBER ALLE GRUPPEN (IRN, rho, etc.)
    for cond_key, stats in bsa_stats.items():
        # Farbe aus config.py holen
        base_color = CONDITION_COLORS.get(cond_key, "#808080")
        group_label = CONDITION_LABELS.get(cond_key, cond_key)
        
        # Mittelwerte für diese Gruppe (D1 und D2)
        # Nutze nanmean falls innerhalb der Gruppe noch NaNs sind
        means = stats["mean"] 
        
        for i in range(means.shape[0]):
            tal_coords = means[i]
            if np.isnan(tal_coords).any():
                continue # Überspringe, falls Koordinate fehlt
                
            # Umrechnung nach MNI
            mni_coords = tal2mni(tal_coords)[0]
            
            # Kugel erstellen
            side = "L" if mni_coords[0] < 0 else "R"
            full_label = f"{group_label} (D{i+1} {side})"
            
            sphere = _sphere_mesh(mni_coords, base_color, full_label)
            dipole_traces.append(sphere)

    # Layout & Speichern
    fig = go.Figure(data=brain_traces + dipole_traces)
    fig.update_layout(
        title="Kombinierte Dipolpositionen (MNI Space)",
        scene=dict(xaxis_visible=False, yaxis_visible=False, zaxis_visible=False, bgcolor="white"),
        margin=dict(l=0, r=0, b=0, t=40),
        legend=dict(itemsizing='constant')
    )
    
    # Speichern der interaktiven HTML
    out_path = output_dir / "combined_3d_brain.html"
    html_str = fig.to_html(include_plotlyjs='cdn')
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(html_str.replace('</body>', _SLIDER_JS + '</body>'))

    # NEU: Automatischer PNG-Export für Publikationen (falls kaleido installiert ist)
    try:
        fig.write_image(str(output_dir / "combined_brain_snapshot.png"), scale=2)
    except: pass 


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def main() -> None:
    print("=" * 60)
    print("  Dipole Brain Visualisation")
    print("=" * 60)

    if not BASE_DIR.exists():
        print(f"\n  ERROR: {BASE_DIR} not found.")
        sys.exit(1)

    print("\n  Loading BSA files …\n")
    data = load_all_subjects(BASE_DIR, SUBJECTS, CONDITIONS)

    output_dir = OUTPUT_DIR
    output_dir.mkdir(parents=True, exist_ok=True)

    plot_dipoles_on_brain(data, output_dir=output_dir, backend="auto")
    print("\n  Done.")


if __name__ == "__main__":
    main()
