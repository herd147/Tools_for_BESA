from pathlib import Path

# Basis-Einstellungen
BASE_DIR = Path(".")
OUTPUT_DIR = Path("./ergebnisse")

# Hier definierst du die Farben für deine Bedingungen (wie in deinem Bild)
# Du kannst hier einfach die Dateinamen deiner CSVs eintragen
# config.py

# config.py
CONDITION_COLORS = {
    "talairach_irn_pts": "#ff7f0e",  # Orange für IRN Patienten
    "talairach_irn_ctrl": "#8787eb", # Hellblau für IRN Kontrollen
    "talairach_rho_pts": "#ff7f0e",  
    "talairach_rho_ctrl": "#8787eb", 
}

CONDITION_LABELS = {
    "talairach_irn_pts": "Patienten (IRN)",
    "talairach_irn_ctrl": "Kontrollen (IRN)",
    "talairach_rho_pts": "Patienten (ρ)",
    "talairach_rho_ctrl": "Kontrollen (ρ)",
}

# Diese Listen können leer bleiben, wenn wir sie nicht nutzen
SUBJECTS = []
CONDITIONS = []