"""
plots.py
--------
All matplotlib figures:
  - plot_grand_averages      2×2 grid, SD1 bottom-left … SD4 top-right
  - plot_permutation_results t-value time courses with significant clusters
  - plot_leonard_map         Dipole locations on auditory cortex anatomy
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches

from config import CONDITION_COLORS, CONDITION_LABELS
class GrandAverage: pass
class PermTestSummary: pass


# ---------------------------------------------------------------------------
# Grand averages  (2×2)
# ---------------------------------------------------------------------------


def plot_grand_averages(
    grand_averages: Dict[str, GrandAverage],
    output_path: Path,
) -> None:
    """
    2×2 grid of grand-average waveforms.

    Layout (anatomical convention – left hemisphere bottom):
        top-left:    SD 3   top-right:    SD 4
        bottom-left: SD 1   bottom-right: SD 2
    """
    if not grand_averages:
        return

    first_ga = next(iter(grand_averages.values()))
    n_sources = first_ga.mean.shape[0]
    wave_names = first_ga.wave_names

    # SD index → (row, col)
    _pos = {0: (1, 0), 1: (1, 1), 2: (0, 0), 3: (0, 1)}

    n_rows = 2 if n_sources > 1 else 1
    n_cols = 2 if n_sources > 1 else 1

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(14, 8), constrained_layout=True)
    fig.suptitle("BESA Grand Averages – all conditions", fontsize=14, fontweight="bold")

    axes = np.atleast_2d(axes)

    for src_idx in range(n_sources):
        row, col = _pos.get(src_idx, (src_idx // 2, src_idx % 2))
        ax = axes[row, col]
        name = wave_names[src_idx] if src_idx < len(wave_names) else f"SD{src_idx + 1}"

        ax.set_title(f"SD {src_idx + 1}: {name}", fontsize=10, loc="left")
        ax.axhline(0, color="k", lw=0.5, ls="--")
        ax.axvline(0, color="k", lw=0.5, ls="--")

        for cond, ga in grand_averages.items():
            if src_idx >= ga.mean.shape[0]:
                continue
            color = CONDITION_COLORS.get(cond, "gray")
            label = f"{CONDITION_LABELS.get(cond, cond)} (n={ga.n_subjects})"
            wf = ga.mean[src_idx]
            se = ga.sem[src_idx]
            ax.plot(ga.time, wf, color=color, lw=1.5, label=label)
            ax.fill_between(ga.time, wf - se, wf + se, color=color, alpha=0.2)

        ax.set_xlabel("Time (ms)", fontsize=9)
        ax.set_ylabel("Amplitude", fontsize=9)
        ax.legend(fontsize=8, loc="upper right", framealpha=0.7)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    for src_idx in range(n_sources, n_rows * n_cols):
        row, col = _pos.get(src_idx, (src_idx // 2, src_idx % 2))
        axes[row, col].set_visible(False)

    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    print(f"\n  Grand average plot: {output_path}")
    plt.show()


# ---------------------------------------------------------------------------
# Permutation test results
# ---------------------------------------------------------------------------


def plot_permutation_results(
    summaries: List[PermTestSummary],
    output_path: Path,
    grand_averages: Dict[str, GrandAverage] = None,
) -> None:
    """
    For each onset/melody pair: 2×2 grid showing
      - t-value time course (onset − melody)
      - significant clusters highlighted
      - grand-average waveforms overlaid (if grand_averages provided)

    One PNG file per pair, named  <output_path_stem>_<pair>.png
    """
    if not summaries:
        return

    for summary in summaries:
        pair_label = f"{summary.cond_onset}_vs_{summary.cond_melody}"
        pair_path = output_path.parent / f"{output_path.stem}_{pair_label}.png"

        n_sources = len(summary.results)
        if n_sources == 0:
            continue

        _pos = {0: (1, 0), 1: (1, 1), 2: (0, 0), 3: (0, 1)}
        n_rows, n_cols = 2, 2

        fig, axes = plt.subplots(
            n_rows, n_cols, figsize=(14, 8), constrained_layout=True
        )
        fig.suptitle(
            f"Permutation test: {CONDITION_LABELS.get(summary.cond_onset, summary.cond_onset)}"
            f"  vs  {CONDITION_LABELS.get(summary.cond_melody, summary.cond_melody)}"
            f"  (n={summary.n_subjects})",
            fontsize=13,
            fontweight="bold",
        )
        axes = np.atleast_2d(axes)

        col_onset = CONDITION_COLORS.get(summary.cond_onset, "#333333")
        col_melody = CONDITION_COLORS.get(summary.cond_melody, "#999999")

        for res in summary.results:
            row, col = _pos.get(
                res.source_idx, (res.source_idx // 2, res.source_idx % 2)
            )
            ax = axes[row, col]

            ax.set_title(
                f"SD {res.source_idx + 1}: {res.source_name}", fontsize=10, loc="left"
            )
            ax.axhline(0, color="k", lw=0.5, ls="--")
            ax.axvline(0, color="k", lw=0.5, ls="--")

            # t-value
            ax.plot(
                res.time, res.t_obs, color="#444444", lw=1.5, label="t (onset−melody)"
            )

            # Grand-average waveforms (if available)
            if grand_averages is not None:
                ax2 = ax.twinx()
                for cond, col_c in [
                    (summary.cond_onset, col_onset),
                    (summary.cond_melody, col_melody),
                ]:
                    if cond in grand_averages:
                        ga = grand_averages[cond]
                        if res.source_idx < ga.mean.shape[0]:
                            lbl = CONDITION_LABELS.get(cond, cond)
                            ax2.plot(
                                ga.time,
                                ga.mean[res.source_idx],
                                color=col_c,
                                lw=1.2,
                                alpha=0.6,
                                ls="--",
                                label=lbl,
                            )
                ax2.set_ylabel("Amplitude", fontsize=8, color="gray")
                ax2.tick_params(axis="y", labelcolor="gray", labelsize=7)
                ax2.spines["top"].set_visible(False)

            # Significant cluster shading
            for clust in res.clusters:
                s_i, e_i = clust["start_idx"], clust["end_idx"]
                color = "#d62728" if clust["significant"] else "#aec7e8"
                alpha = 0.30 if clust["significant"] else 0.15
                ax.axvspan(
                    res.time[s_i],
                    res.time[e_i],
                    color=color,
                    alpha=alpha,
                    label=f"p={clust['p_value']:.3f}" if clust["significant"] else None,
                )

            ax.set_xlabel("Time (ms)", fontsize=9)
            ax.set_ylabel("t-value", fontsize=9)
            ax.legend(fontsize=7, loc="upper right", framealpha=0.7)
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)

        for src_idx in range(n_sources, n_rows * n_cols):
            row, col = _pos.get(src_idx, (src_idx // 2, src_idx % 2))
            axes[row, col].set_visible(False)

        fig.savefig(pair_path, dpi=150, bbox_inches="tight")
        print(f"  Permutation plot:  {pair_path}")
        plt.show()


# ---------------------------------------------------------------------------
# Leonard map
# ---------------------------------------------------------------------------


def _leonard_anatomy() -> dict:
    """Anatomical landmarks from Leonard et al. (1998)."""

    def px2mm(rows, sx, ox, sy, oy):
        a = np.array(rows, dtype=float)
        a[:, 0] = a[:, 0] * sx + ox
        a[:, 1] = a[:, 1] * sy + oy
        return a

    pt_p_l = px2mm(
        [
            [92, 517],
            [118, 516],
            [126, 517],
            [147, 522],
            [159, 521],
            [170, 526],
            [181, 527],
            [215, 537],
        ],
        0.1818,
        -72.72,
        0.2222,
        -159.33,
    )
    pt_p_r = px2mm(
        [
            [300, 560],
            [322, 557],
            [346, 562],
            [357, 565],
            [367, 566],
            [390, 570],
            [404, 574],
            [414, 578],
            [424, 582],
        ],
        0.1756,
        -18.82,
        0.2222,
        -159.33,
    )
    hg_p_l = px2mm(
        [
            [92, 637],
            [104, 632],
            [114, 630],
            [126, 622],
            [137, 615],
            [148, 606],
            [160, 593],
            [170, 586],
            [181, 574],
            [192, 567],
            [215, 559],
        ],
        0.1818,
        -72.72,
        0.2222,
        -159.33,
    )
    hg_p_r = px2mm(
        [
            [300, 574],
            [312, 579],
            [323, 586],
            [345, 608],
            [358, 617],
            [368, 623],
            [379, 628],
            [390, 635],
            [401, 641],
            [413, 644],
            [424, 640],
        ],
        0.1756,
        -18.82,
        0.2222,
        -159.33,
    )
    hg_a_l = px2mm(
        [
            [92, 683],
            [102, 681],
            [114, 675],
            [125, 673],
            [136, 663],
            [147, 649],
            [158, 628],
            [180, 607],
            [192, 598],
            [215, 590],
        ],
        0.1818,
        -72.72,
        0.2222,
        -159.33,
    )
    hg_a_r = px2mm(
        [
            [300, 606],
            [311, 611],
            [322, 622],
            [334, 637],
            [344, 646],
            [368, 677],
            [379, 691],
            [391, 700],
            [403, 704],
            [424, 706],
        ],
        0.1756,
        -18.82,
        0.2222,
        -159.33,
    )

    return dict(
        pt_p_l=pt_p_l,
        pt_p_r=pt_p_r,
        hg_p_l=hg_p_l,
        hg_p_r=hg_p_r,
        hg_a_l=hg_a_l,
        hg_a_r=hg_a_r,
    )


def _draw_anatomy(ax: plt.Axes) -> None:
    anat = _leonard_anatomy()

    def area_poly(x, y):
        return (np.concatenate([x, x[::-1]]), np.concatenate([y, np.zeros(len(y))]))

    for side in ("l", "r"):
        pt_p = anat[f"pt_p_{side}"]
        hg_p = anat[f"hg_p_{side}"]
        hg_a = anat[f"hg_a_{side}"]

        px, py = area_poly(pt_p[:, 0], pt_p[:, 1])
        ax.fill(px, py, color=[0.9, 0.9, 0.9], zorder=1, lw=0)
        ax.plot(pt_p[:, 0], pt_p[:, 1], "k-", lw=0.8, zorder=2)

        px, py = area_poly(hg_p[:, 0], hg_p[:, 1])
        ax.fill(px, py, color=[0.7, 0.7, 0.7], zorder=3, lw=0)
        ax.plot(hg_p[:, 0], hg_p[:, 1], "k-", lw=0.8, zorder=4)

        px, py = area_poly(hg_a[:, 0], hg_a[:, 1])
        ax.fill(px, py, color=[1.0, 1.0, 1.0], zorder=5, lw=0)
        ax.plot(hg_a[:, 0], hg_a[:, 1], "k-", lw=0.8, zorder=6)


def plot_leonard_map(
    bsa_stats: Dict[str, dict],
    output_path: Path,
) -> None:
    """
    Zeignet alle Bedingungen (IRN & rho) auf der Anatomie des auditiven Cortex.
    """
    if not bsa_stats:
        return

    fig, (ax_l, ax_r) = plt.subplots(
        1, 2, sharey=True, gridspec_kw={"wspace": 0.06}, figsize=(12, 8)
    )
    fig.suptitle("Dipolpositionen nach Leonard et al. (1998)", fontsize=16)

    # 1. Anatomie zeichnen (HG und PT)
    for ax, xlim, side_label in [
        (ax_l, (-60, -30), "links"),
        (ax_r, (30, 60), "rechts"),
    ]:
        _draw_anatomy(ax) # Nutzt hg_a_l, hg_p_l etc. aus plots.py
        ax.set_xlim(*xlim)
        ax.set_ylim(-50, 10)
        ax.set_aspect("equal")
        ax.xaxis.set_major_locator(plt.MultipleLocator(10))
        ax.yaxis.set_major_locator(plt.MultipleLocator(10))
        ax.text(xlim[0] + 1, 8.5, side_label, fontsize=11, color="gray")

    legend_h = []
    
    # 2. Datenreihen plotten
    # Wir sortieren, damit die Reihenfolge in der Legende stabil bleibt
    for cond in sorted(bsa_stats.keys()):
        stats = bsa_stats[cond]
        color = CONDITION_COLORS.get(cond, "gray")
        lbl_str = CONDITION_LABELS.get(cond, cond)
        
        # Marker: Dreieck für Patienten, Kreis für Kontrollen
        marker = "^" if ("rho" in cond.lower()) else "o"
        

        for si in range(stats["mean"].shape[0]):
            # Talairach X und Y aus deinen CSV-Daten
            mx = stats["mean"][si, 0]
            my = stats["mean"][si, 1]
            sx = stats["std"][si, 0]
            sy = stats["std"][si, 1]
            
            ax = ax_l if mx < 0 else ax_r
            lbl = f"{lbl_str} (n={stats['n']})" if si == 0 else "_nolegend_"

            # Den Dipol zeichnen (hohle Symbole)
            h = ax.plot(
                mx, my, marker,
                color=color,
                markerfacecolor='none',
                markeredgewidth=1.5,
                markersize=9,
                zorder=10,
                label=lbl
            )
            
            if si == 0:
                legend_h.append(h[0])

            # Fehlerbalken (SD)
            ax.plot([mx - sx, mx + sx], [my, my], color=color, lw=1.2, alpha=0.8, zorder=7)
            ax.plot([mx, mx], [my - sy, my + sy], color=color, lw=1.2, alpha=0.8, zorder=7)

    # 3. Layout & Legende
    ax_l.set_ylabel("Talairach Y (mm)", fontsize=13)
    ax_l.set_xlabel("Talairach X (mm)", fontsize=13)
    ax_r.set_xlabel("Talairach X (mm)", fontsize=13)
    
    # Legende rechts neben dem Plot platzieren
    ax_r.legend(handles=legend_h, fontsize=9, loc='center left', 
                bbox_to_anchor=(1.05, 0.5), borderaxespad=0.)

    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    print(f"Plot erstellt: {output_path}")
    plt.show()


# ---------------------------------------------------------------------------
# Per-subject Leonard map  (BESA error check)
# ---------------------------------------------------------------------------

# SD colours consistent with brain_plot.SD_COLORS
_SD_COLORS_LIST = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"]


def extract_subject_bsa_positions(
    data: Dict,
    conditions: List[str] | None = None,
) -> Dict[str, Dict[str, np.ndarray]]:
    """
    Extract per-subject, per-condition Talairach BSA dipole positions
    from the raw data dict returned by ``load_all_subjects``.

    Parameters
    ----------
    data
        ``{ condition: [SubjectData, ...] }`` as returned by
        ``load_all_subjects``.  Each ``SubjectData`` has attributes
        ``subject_id``, ``condition``, and ``bsa`` (a ``BsaData``
        object whose ``coords`` array has shape ``(n_sources, 3)``).
    conditions
        Optional list of condition keys to include.  Defaults to all.

    Returns
    -------
    { subject_id : { condition : ndarray (n_sources, 3) } }
        Talairach coordinates in mm.  Subjects without a valid BSA
        file for a given condition are silently skipped for that
        condition only.
    """
    out: Dict[str, Dict[str, np.ndarray]] = {}
    conds = conditions if conditions is not None else list(data.keys())

    for cond in conds:
        if cond not in data:
            continue
        for sd in data[cond]:  # sd is a SubjectData instance
            if sd.bsa is None:
                continue
            coords = getattr(sd.bsa, "coords", None)
            if coords is None:
                continue
            arr = np.asarray(coords, dtype=float)
            if arr.ndim == 1:
                arr = arr[np.newaxis, :]  # (3,) → (1, 3)
            out.setdefault(sd.subject_id, {})[cond] = arr[:, :3]

    if not out and data:
        raise ValueError(
            "extract_subject_bsa_positions: no BSA coordinate arrays found. "
            "Check that .bsa files were loaded and that BsaData.coords is set."
        )

    return out


def _print_outlier_summary(
    all_outliers: Dict[str, Dict[str, List[str]]],
    n_sd_threshold: float,
) -> None:
    """Print a formatted outlier table to stdout."""
    sep = "=" * 62
    print(f"\n{sep}")
    print(f"  BESA Error Check – Outlier Summary  (threshold: {n_sd_threshold:.1f} SD)")
    print(sep)

    any_out = False
    for cond, cond_out in sorted(all_outliers.items()):
        if not cond_out:
            continue
        any_out = True
        print(f"\n  {CONDITION_LABELS.get(cond, cond)}:")
        for subj, src_list in sorted(cond_out.items()):
            srcs = ", ".join(sorted(set(src_list)))
            print(f"    {subj:<16}  →  {srcs}")

    if not any_out:
        print(f"\n  No outliers found at threshold {n_sd_threshold:.1f} SD.")
    print(f"{sep}\n")


def _draw_subject_sd(
    ax: plt.Axes,
    si: int,
    subj_pos: Dict[str, np.ndarray],
    stats: dict,
    src_lbl: str,
    n_sd_threshold: float,
    cond_outliers: Dict[str, List[str]],
    label_fontsize: int = 6,
    col_x: int = 0,
    col_y: int = 1,
) -> None:
    """
    Draw one SD source for all subjects onto *ax* using VP-IDs as markers.

    Each subject is rendered as their ID string at the exact coordinate:
      • inlier  – small, semi-transparent text in the SD colour
      • outlier – bold black text with a coloured box border; added to
                  *cond_outliers* for the summary table

    Additionally draws: group mean crosshairs, 1-SD ellipse, source label.

    Parameters
    ----------
    col_x, col_y
        Which columns of the (n_sources, ≥3) coords array to use as
        x and y axes.  Defaults are 0 (Talairach X) and 1 (Talairach Y).
        Pass col_y=2 for a lateral X-vs-Z view.
    """
    mx = stats["mean"][si, col_x]
    my = stats["mean"][si, col_y]
    sx = stats["std"][si, col_x]
    sy = stats["std"][si, col_y]
    sd_col = _SD_COLORS_LIST[min(si, len(_SD_COLORS_LIST) - 1)]

    # ── Per-subject VP-ID labels ────────────────────────────────────────────
    for subj, pos in subj_pos.items():
        if si >= pos.shape[0]:
            continue
        px = pos[si, col_x]
        py = pos[si, col_y]

        # Outlier: deviates beyond threshold in x *or* y
        dev_x = abs(px - mx) / (sx + 1e-9)
        dev_y = abs(py - my) / (sy + 1e-9)
        is_out = dev_x > n_sd_threshold or dev_y > n_sd_threshold

        if is_out:
            cond_outliers.setdefault(subj, []).append(src_lbl)
            ax.text(
                px,
                py,
                subj,
                fontsize=label_fontsize,
                fontweight="bold",
                color="k",
                ha="center",
                va="center",
                zorder=13,
                bbox=dict(
                    boxstyle="round,pad=0.2", fc="white", ec=sd_col, alpha=0.88, lw=1.2
                ),
            )
        else:
            ax.text(
                px,
                py,
                subj,
                fontsize=label_fontsize,
                color=sd_col,
                ha="center",
                va="center",
                alpha=0.65,
                zorder=9,
            )

    # ── Group mean ± 1 SD ───────────────────────────────────────────────────
    ax.plot([mx - sx, mx + sx], [my, my], color=sd_col, lw=2.0, zorder=14)
    ax.plot([mx, mx], [my - sy, my + sy], color=sd_col, lw=2.0, zorder=14)
    ell = mpatches.Ellipse(
        xy=(mx, my),
        width=2 * sx,
        height=2 * sy,
        edgecolor=sd_col,
        facecolor="none",
        linewidth=1.2,
        linestyle="--",
        zorder=13,
        alpha=0.7,
    )
    ax.add_patch(ell)
    # Central crosshair marker (no filled dot – would obscure text)
    ax.plot(mx, my, "+", color=sd_col, markersize=11, markeredgewidth=2.0, zorder=15)
    ax.annotate(
        src_lbl,
        xy=(mx, my),
        xytext=(5, 5),
        textcoords="offset points",
        fontsize=8,
        fontweight="bold",
        color=sd_col,
        zorder=16,
    )


def _add_axis_break(fig: plt.Figure, ax_l: plt.Axes, ax_r: plt.Axes) -> None:
    """Draw axis-break tick marks between the two Leonard panels."""
    break_kw = dict(transform=fig.transFigure, color="k", lw=1, clip_on=False)
    for ax, sign in [(ax_l, +1), (ax_r, -1)]:
        x0 = ax.get_position().x1 if sign == +1 else ax.get_position().x0
        y0, y1 = ax.get_position().y0, ax.get_position().y1
        dx, dy = 0.008, 0.015
        for yf in [y0 + 0.03, y1 - 0.03]:
            fig.lines.append(
                plt.Line2D(
                    [x0 - dx * sign, x0 + dx * sign], [yf - dy, yf + dy], **break_kw
                )
            )


def plot_leonard_map_subjects(
    subject_bsa: Dict[str, Dict[str, np.ndarray]],
    bsa_stats: Dict[str, dict],
    output_path: Path,
    n_sd_threshold: float = 2.5,
) -> None:
    """
    Per-subject dipole locations on Leonard et al. (1998) anatomy for BESA
    error checking.

    Produces
    --------
    * One PNG per condition:  ``<stem>_subjects_<cond>.png``
    * One combined overview:  ``<stem>_subjects_overview.png``
    * An outlier summary table printed to stdout.

    Parameters
    ----------
    subject_bsa
        ``{ subject_id : { condition : ndarray (n_sources, ≥3) } }``
        Talairach coordinates in mm.  Build this dict with
        :func:`extract_subject_bsa_positions`.
    bsa_stats
        Group statistics as returned by ``compute_bsa_statistics``.
        Used for the reference mean ± SD overlay.
    output_path
        Base path; the condition suffix is appended automatically.
    n_sd_threshold
        Subjects whose ``|pos − group_mean| > threshold × group_SD``
        in either x or y are flagged as outliers.

    Example
    -------
    ::

        data      = load_all_subjects(BASE_DIR, SUBJECTS, CONDITIONS)
        bsa_stats = compute_bsa_statistics(data)
        subj_bsa  = extract_subject_bsa_positions(data)

        plot_leonard_map_subjects(
            subj_bsa, bsa_stats,
            output_path=OUTPUT_DIR / "leonard_subjects.png",
        )
    """
    if not subject_bsa or not bsa_stats:
        print("  plot_leonard_map_subjects: no data – skipped.")
        return

    subjects = sorted(subject_bsa.keys())
    conditions = sorted(bsa_stats.keys())
    n_subj = len(subjects)

    all_outliers: Dict[str, Dict[str, List[str]]] = {}

    # ── Per-condition figures ───────────────────────────────────────────────
    for cond in conditions:
        stats = bsa_stats[cond]
        n_src = stats["mean"].shape[0]
        src_lbls = stats.get("labels", [f"SD{k + 1}" for k in range(n_src)])

        subj_pos: Dict[str, np.ndarray] = {
            subj: np.asarray(subject_bsa[subj][cond])
            for subj in subjects
            if cond in subject_bsa.get(subj, {})
        }
        if not subj_pos:
            continue

        cond_outliers: Dict[str, List[str]] = {}

        fig, (ax_l, ax_r) = plt.subplots(
            1,
            2,
            sharey=True,
            gridspec_kw={"wspace": 0.06},
            figsize=(12, 7),
        )
        lbl_str = CONDITION_LABELS.get(cond, cond)
        n_plotted = len(subj_pos)
        fig.suptitle(
            f"Per-subject dipole locations – {lbl_str}\n"
            f"N = {n_plotted}   |   outlier threshold: {n_sd_threshold:.1f} SD   |   "
            f"◆ = outlier,  ● = inlier,  ⊕ = group mean,  – – = 1 SD",
            fontsize=12,
            fontweight="bold",
        )

        for ax, xlim, side_label in [
            (ax_l, (-60, -30), "links"),
            (ax_r, (30, 60), "rechts"),
        ]:
            _draw_anatomy(ax)
            ax.set_xlim(*xlim)
            ax.set_ylim(-50, 10)
            ax.set_aspect("equal")
            ax.xaxis.set_major_locator(plt.MultipleLocator(10))
            ax.yaxis.set_major_locator(plt.MultipleLocator(10))
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            ax.text(xlim[0] + 1, 8.5, side_label, fontsize=11, color="gray")

        # ── Draw each source ────────────────────────────────────────────────
        legend_handles: List[mpatches.Patch] = []

        for si in range(n_src):
            mx = stats["mean"][si, 0]
            ax = ax_l if mx < 0 else ax_r
            src_lbl = src_lbls[si] if si < len(src_lbls) else f"SD{si + 1}"

            _draw_subject_sd(
                ax,
                si,
                subj_pos,
                stats,
                src_lbl,
                n_sd_threshold,
                cond_outliers,
            )
            legend_handles.append(
                mpatches.Patch(
                    color=_SD_COLORS_LIST[min(si, len(_SD_COLORS_LIST) - 1)],
                    label=src_lbl,
                )
            )

        # ── Axis break + spine styling ──────────────────────────────────────
        _add_axis_break(fig, ax_l, ax_r)
        ax_l.spines["right"].set_visible(False)
        ax_r.spines["left"].set_visible(False)
        ax_r.tick_params(left=False)
        ax_l.set_ylabel("Talairach Y (mm)", fontsize=12)
        ax_l.set_xlabel("Talairach X (mm)", fontsize=12)
        ax_r.set_xlabel("Talairach X (mm)", fontsize=12)

        # ── Legend ──────────────────────────────────────────────────────────
        style_handles = [
            mpatches.Patch(facecolor="gray", alpha=0.4, label="inlier"),
            plt.Line2D(
                [],
                [],
                marker="D",
                color="k",
                markerfacecolor="gray",
                markersize=7,
                lw=0,
                label=f"outlier (> {n_sd_threshold:.1f} SD)",
            ),
            plt.Line2D(
                [], [], marker="o", color="k", markersize=9, lw=0, label="group mean"
            ),
        ]
        ax_r.legend(
            handles=legend_handles + style_handles,
            fontsize=8,
            loc="lower right",
            framealpha=0.85,
        )

        cond_path = output_path.parent / f"{output_path.stem}_subjects_{cond}.png"
        fig.savefig(cond_path, dpi=150, bbox_inches="tight")
        print(f"  Per-subject Leonard ({cond:>12s}):  {cond_path}")
        plt.show()

        all_outliers[cond] = cond_outliers

    # ── Print outlier summary ───────────────────────────────────────────────
    _print_outlier_summary(all_outliers, n_sd_threshold)

    # ── Lateral (X vs Z) plots ──────────────────────────────────────────────
    plot_lateral_subjects(subject_bsa, bsa_stats, output_path, n_sd_threshold)

    # ── Combined overview figure ────────────────────────────────────────────
    _plot_subjects_overview(
        subject_bsa, bsa_stats, subjects, n_sd_threshold, output_path
    )


def _plot_subjects_overview(
    subject_bsa: Dict[str, Dict[str, np.ndarray]],
    bsa_stats: Dict[str, dict],
    subjects: List[str],
    n_sd_threshold: float,
    output_path: Path,
) -> None:
    """
    Combined overview figure: one row per condition, left/right AC columns.
    All SD sources overlaid on the same axes (no per-condition outlier tracking
    here – that is done in :func:`plot_leonard_map_subjects`).
    """
    conditions = sorted(bsa_stats.keys())
    n_cond = len(conditions)
    if n_cond == 0:
        return

    fig, axes = plt.subplots(
        n_cond,
        2,
        sharey="row",
        figsize=(12, 5.5 * n_cond),
        gridspec_kw={"wspace": 0.06, "hspace": 0.38},
    )
    fig.suptitle(
        f"Per-subject dipole overview – all conditions\n"
        f"(outlier threshold: {n_sd_threshold:.1f} SD  |  N = {len(subjects)})",
        fontsize=13,
        fontweight="bold",
    )
    axes = np.atleast_2d(axes)

    for ci, cond in enumerate(conditions):
        stats = bsa_stats[cond]
        n_src = stats["mean"].shape[0]
        src_lbls = stats.get("labels", [f"SD{k + 1}" for k in range(n_src)])
        lbl_str = CONDITION_LABELS.get(cond, cond)

        subj_pos: Dict[str, np.ndarray] = {
            subj: np.asarray(subject_bsa[subj][cond])
            for subj in subjects
            if cond in subject_bsa.get(subj, {})
        }

        for col_idx, (xlim, side_label) in enumerate(
            [
                ((-60, -30), "links"),
                ((30, 60), "rechts"),
            ]
        ):
            ax = axes[ci, col_idx]
            _draw_anatomy(ax)
            ax.set_xlim(*xlim)
            ax.set_ylim(-50, 10)
            ax.set_aspect("equal")
            ax.xaxis.set_major_locator(plt.MultipleLocator(10))
            ax.yaxis.set_major_locator(plt.MultipleLocator(10))
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            ax.text(
                xlim[0] + 1, 8.5, f"{lbl_str} – {side_label}", fontsize=9, color="gray"
            )

            for si in range(n_src):
                mx = stats["mean"][si, 0]
                # Only draw on the anatomically correct hemisphere panel
                if (xlim[0] < 0) != (mx < 0):
                    continue

                src_lbl = src_lbls[si] if si < len(src_lbls) else f"SD{si + 1}"
                _dummy_outliers: Dict[str, List[str]] = {}

                _draw_subject_sd(
                    ax,
                    si,
                    subj_pos,
                    stats,
                    src_lbl,
                    n_sd_threshold,
                    _dummy_outliers,
                    label_fontsize=5,
                )

        axes[ci, 0].spines["right"].set_visible(False)
        axes[ci, 1].spines["left"].set_visible(False)
        axes[ci, 1].tick_params(left=False)
        axes[ci, 0].set_ylabel("Talairach Y (mm)", fontsize=10)

    for ax in axes[-1, :]:
        ax.set_xlabel("Talairach X (mm)", fontsize=10)

    # Axis breaks for each row
    for ci in range(n_cond):
        _add_axis_break(fig, axes[ci, 0], axes[ci, 1])

    overview_path = output_path.parent / f"{output_path.stem}_subjects_overview.png"
    fig.savefig(overview_path, dpi=150, bbox_inches="tight")
    print(f"  Per-subject overview:          {overview_path}")
    plt.show()


# ---------------------------------------------------------------------------
# Lateral (X vs Z) per-subject plot
# ---------------------------------------------------------------------------


def plot_lateral_subjects(
    subject_bsa: Dict[str, Dict[str, np.ndarray]],
    bsa_stats: Dict[str, dict],
    output_path: Path,
    n_sd_threshold: float = 2.5,
) -> None:
    """
    Per-subject dipole positions in the lateral plane (Talairach X vs Z).

    Complements the Leonard map (X vs Y) by making height errors visible.
    Each subject is labelled by their VP-ID directly in the plot.

    Produces
    --------
    * One PNG per condition: ``<stem>_lateral_<cond>.png``

    Parameters
    ----------
    subject_bsa
        As returned by :func:`extract_subject_bsa_positions`.
    bsa_stats
        Group statistics from ``compute_bsa_statistics``.
    output_path
        Base path; condition suffix appended automatically.
    n_sd_threshold
        Outlier threshold in SD units (same definition as in
        :func:`plot_leonard_map_subjects`).
    """
    if not subject_bsa or not bsa_stats:
        print("  plot_lateral_subjects: no data – skipped.")
        return

    subjects = sorted(subject_bsa.keys())
    conditions = sorted(bsa_stats.keys())

    for cond in conditions:
        stats = bsa_stats[cond]
        n_src = stats["mean"].shape[0]
        src_lbls = stats.get("labels", [f"SD{k + 1}" for k in range(n_src)])
        lbl_str = CONDITION_LABELS.get(cond, cond)

        # Check we have a Z column
        if stats["mean"].shape[1] < 3:
            print(f"  plot_lateral_subjects: no Z column for {cond} – skipped.")
            continue

        subj_pos: Dict[str, np.ndarray] = {
            subj: np.asarray(subject_bsa[subj][cond])
            for subj in subjects
            if cond in subject_bsa.get(subj, {})
        }
        if not subj_pos:
            continue

        # Two panels: left hemisphere (X < 0) | right hemisphere (X > 0)
        fig, (ax_l, ax_r) = plt.subplots(
            1,
            2,
            figsize=(14, 6),
            gridspec_kw={"wspace": 0.25},
        )
        n_plotted = len(subj_pos)
        fig.suptitle(
            f"Lateral view (X vs Z) \u2013 {lbl_str}\n"
            f"N = {n_plotted}   |   outlier threshold: {n_sd_threshold:.1f} SD   |   "
            "boxed = outlier,  plain = inlier,  + = group mean,  \u2013\u2013 = 1 SD",
            fontsize=12,
            fontweight="bold",
        )

        legend_handles: List[mpatches.Patch] = []

        for ax, hemi_sign, side_label in [
            (ax_l, -1, "Linke Hemisphäre  (X < 0)"),
            (ax_r, +1, "Rechte Hemisphäre (X > 0)"),
        ]:
            ax.axhline(0, color="k", lw=0.5, ls="--", alpha=0.4)
            ax.axvline(0, color="k", lw=0.5, ls="--", alpha=0.4)
            ax.set_xlabel("Talairach X (mm)", fontsize=11)
            ax.set_ylabel("Talairach Z (mm)", fontsize=11)
            ax.set_title(side_label, fontsize=10, color="gray", loc="left")
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            ax.xaxis.set_major_locator(plt.MultipleLocator(5))
            ax.yaxis.set_major_locator(plt.MultipleLocator(5))
            ax.grid(True, lw=0.3, alpha=0.4, linestyle=":")

            for si in range(n_src):
                mx = stats["mean"][si, 0]  # Talairach X determines hemisphere
                if np.sign(mx) != hemi_sign:
                    continue

                src_lbl = src_lbls[si] if si < len(src_lbls) else f"SD{si + 1}"
                _dummy_outliers: Dict[str, List[str]] = {}

                _draw_subject_sd(
                    ax,
                    si,
                    subj_pos,
                    stats,
                    src_lbl,
                    n_sd_threshold,
                    _dummy_outliers,
                    label_fontsize=7,
                    col_x=0,
                    col_y=2,  # X vs Z
                )

                if ax is ax_l:
                    sd_col = _SD_COLORS_LIST[min(si, len(_SD_COLORS_LIST) - 1)]
                    legend_handles.append(mpatches.Patch(color=sd_col, label=src_lbl))

        style_handles = [
            plt.Line2D(
                [],
                [],
                marker="$VP$",
                color="gray",
                markersize=10,
                lw=0,
                alpha=0.65,
                label="inlier (VP-ID)",
            ),
            plt.Line2D(
                [],
                [],
                marker="$VP$",
                color="k",
                markersize=10,
                lw=0,
                label=f"outlier (> {n_sd_threshold:.1f} SD, boxed)",
            ),
            plt.Line2D(
                [],
                [],
                marker="+",
                color="k",
                markersize=10,
                markeredgewidth=2,
                lw=0,
                label="group mean (+)",
            ),
        ]
        ax_r.legend(
            handles=legend_handles + style_handles,
            fontsize=8,
            loc="best",
            framealpha=0.85,
        )

        lat_path = output_path.parent / f"{output_path.stem}_lateral_{cond}.png"
        fig.savefig(lat_path, dpi=150, bbox_inches="tight")
        print(f"  Lateral view ({cond:>16s}):  {lat_path}")
        plt.show()
