import os
import numpy as np
import json

class DataRow:
    def __init__(self, Untersuchungsdatum, Geburtsdatum, ID, GD1, GD2, HP1, HP2, Messung):
        self.Untersuchungsdatum = Untersuchungsdatum
        self.Geburtsdatum = Geburtsdatum
        self.ID = ID
        self.GD1 = GD1
        self.GD2 = GD2
        self.HP1 = HP1
        self.HP2 = HP2
        self.Messung = Messung

    def __repr__(self):
        return f"DataRow(ID={self.ID}, Messung={self.Messung})"

def extract_bsa_coordinates(datapath, dirs, ids, file_prefix="", suffixes=["_av.bsa"]):
    all_patients_coords = []

    for folder, patient_id in zip(dirs, ids):
        found_coords = []
        file_path_to_read = None
        
        for suffix in suffixes:
            filename = f"{file_prefix}_{patient_id}{suffix}"
            test_path = os.path.join(datapath, folder, filename)
            
            if os.path.exists(test_path):
                file_path_to_read = test_path
                break 
        
        if file_path_to_read:
            # --- DEBUG PRINT START ---
            print(f"Verarbeite Datei: {os.path.basename(file_path_to_read)}")
            # --- DEBUG PRINT END ---
            
            try:
                with open(file_path_to_read, 'r') as f:
                    lines = f.readlines()
                    data_start = False
                    for line in lines:
                        if "====" in line:
                            data_start = True
                            continue
                        if data_start and line.strip():
                            parts = line.split()
                            try:
                                x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                                found_coords.append([x, y, z])
                                
                                # --- DEBUG PRINT X-WERTE ---
                                print(f"  Gefundener x-Wert: {x}")
                                
                            except (ValueError, IndexError):
                                print(f"  WARNUNG: Konnte Zeile nicht lesen: {line.strip()}")
                                continue
            except Exception as e:
                print(f"FEHLER beim Lesen von {os.path.basename(file_path_to_read)}: {e}")
        else:
            print(f"DATEI NICHT GEFUNDEN für ID {patient_id} in {folder}")
        
        while len(found_coords) < 2:
            found_coords.append([np.nan, np.nan, np.nan])
        
        all_patients_coords.append(found_coords[:2])
    
    return np.array(all_patients_coords)

# ---- Ausführen ----
datapath = "D:\\"

# JSON Dateien laden
try:
    data = json.load(open('TabelleJSON.json'))
    data2 = json.load(open('TabelleJSON_ctrl.json'))
except FileNotFoundError as e:
    print(f"JSON Datei nicht gefunden: {e}")
    data, data2 = [], []

# Objekte erstellen
data_rows = [DataRow(**row) for row in data]
data_rows2 = [DataRow(**row) for row in data2]

# Ausschlussliste
excluded_ids = [4253, 4278, 4890, 1639437, 1985694, 1757222, 3212831, 3242668, 181224, 4610, 4838, 210225, 3660, 4822, 4838, 4882, 4818, 4646]
data_rows_edited = [row for row in data_rows if row.ID not in excluded_ids]
data_rows_edited2 = [row for row in data_rows2 if row.ID not in excluded_ids]

# Verzeichnisse und IDs extrahieren
dirs = [row.Messung for row in data_rows_edited]
dirs2 = [row.Messung for row in data_rows_edited2]
ID = [str(row.ID) for row in data_rows_edited]
ID2 = [str(row.ID) for row in data_rows_edited2]

# --- Koordinaten Extraktion ---

# IRN bleibt beim Standard (_av.bsa)
talairach_pts_irn = extract_bsa_coordinates(datapath, dirs, ID, file_prefix="irn")
talairach_ctrl_irn = extract_bsa_coordinates(datapath, dirs2, ID2, file_prefix="irn")

# RHO priorisiert _av_3.bsa vor _av_1.bsa
rho_suffixes = ["_av_3.bsa", "_av_1.bsa"]

talairach_pts_rho = extract_bsa_coordinates(datapath, dirs, ID, file_prefix="rho", suffixes=rho_suffixes)
talairach_ctrl_rho = extract_bsa_coordinates(datapath, dirs2, ID2, file_prefix="rho", suffixes=rho_suffixes)

# Flatten für den CSV-Export (n, 6 Spalten)
flattened_coords_irn_pts = talairach_pts_irn.reshape(len(talairach_pts_irn), 6)
flattened_coords_irn_ctrl = talairach_ctrl_irn.reshape(len(talairach_ctrl_irn), 6)
flattened_coords_rho_pts = talairach_pts_rho.reshape(len(talairach_pts_rho), 6)
flattened_coords_rho_ctrl = talairach_ctrl_rho.reshape(len(talairach_ctrl_rho), 6)

# Speichern der Ergebnisse
np.savetxt("talairach_irn_pts.csv", flattened_coords_irn_pts, delimiter=",", header="D1_X,D1_Y,D1_Z,D2_X,D2_Y,D2_Z", comments="")
np.savetxt("talairach_irn_ctrl.csv", flattened_coords_irn_ctrl, delimiter=",", header="D1_X,D1_Y,D1_Z,D2_X,D2_Y,D2_Z", comments="")
np.savetxt("talairach_rho_pts.csv", flattened_coords_rho_pts, delimiter=",", header="D1_X,D1_Y,D1_Z,D2_X,D2_Y,D2_Z", comments="")
np.savetxt("talairach_rho_ctrl.csv", flattened_coords_rho_ctrl, delimiter=",", header="D1_X,D1_Y,D1_Z,D2_X,D2_Y,D2_Z", comments="")

print("Fertig! Die RHO-Daten wurden mit Priorität auf _av_3 extrahiert.")