import pandas as pd
import numpy as np
from pathlib import Path

# Wir importieren die Funktionen aus deinen Dateien
# Stellen sicher, dass plots.py und brain_plot.py im gleichen Ordner liegen
from plots import plot_leonard_map
from brain_plot import plot_dipoles_on_brain

def process_csv_folder(input_folder: str, output_folder: str, plot_name: str = "combined_leonard_map"):
    input_dir = Path(input_folder)
    out_dir = Path(output_folder)
    out_dir.mkdir(parents=True, exist_ok=True)
    
    all_conditions_stats = {}
    csv_files = list(input_dir.glob("*.csv"))
    
    for csv_path in csv_files:
        file_stem = csv_path.stem.lower()
        
        # Bestimmung der Bedingung (IRN vs RHO)
        cond_type = "irn" if "irn" in file_stem else "rho"
        
        # Bestimmung der Gruppe (Patienten vs Kontrollen)
        # Sucht nach 'pts' oder 'patient' im Dateinamen
        group_type = "pts" if any(x in file_stem for x in ["pts", "patient"]) else "ctrl"
        
        # Der finale Key für config.py (z.B. talairach_irn_pts)
        label = f"talairach_{cond_type}_{group_type}"
        
        try:
            df = pd.read_csv(csv_path)
            
            # Wir nutzen D1_X, D1_Y, D1_Z etc. (wie in deinem Bild)
            # .values konvertiert zu numpy
            d1 = df[['D1_X', 'D1_Y', 'D1_Z']].values
            d2 = df[['D2_X', 'D2_Y', 'D2_Z']].values
            
            # Stack zu (Anzahl_Probanden, 2_Dipole, 3_Koordinaten)
            all_coords = np.stack([d1, d2], axis=1)
            
            # Statistik berechnen und dabei NaNs ignorieren!
            all_conditions_stats[label] = {
                "mean": np.nanmean(all_coords, axis=0), 
                "std": np.nanstd(all_coords, axis=0),
                "n": len(df[~df['D1_X'].isna()]), # Zählt nur Zeilen ohne NaNs
                "labels": ["Links (D1)", "Rechts (D2)"]
            }
            print(f"  ✓ {csv_path.name} zugeordnet zu: {label}")
            
        except Exception as e:
            print(f"  ✖ Fehler bei {csv_path.name}: {e}")

    # Plotten mit den gesammelten Daten
    plot_leonard_map(all_conditions_stats, out_dir / f"{plot_name}.png")
    
    # B. Gemeinsamer 3D Brain Plot (MNI Space)
    # Wir übergeben das gesamte Dictionary, damit alle Bedingungen in einem Hirn landen
    print("\nErstelle kombinierten 3D-Plot für alle Bedingungen...")
    plot_dipoles_on_brain(all_conditions_stats, output_dir=out_dir, backend="plotly")
    
if __name__ == "__main__":
    # --- ANPASSEN ---
    # Erstelle einen Ordner "meine_daten" und lege deine CSVs hinein
    # Erstelle einen Ordner "ergebnisse" für die Plots
    ordner_mit_csvs = "./meine_daten" 
    ausgabe_ordner = "./ergebnisse"
    name_des_plots = "Vergleich_Heschl_Gyrus"
    
    process_csv_folder(ordner_mit_csvs, ausgabe_ordner, name_des_plots)